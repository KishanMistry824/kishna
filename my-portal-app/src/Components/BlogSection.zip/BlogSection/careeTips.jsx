import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  FileText,
  Terminal,
  Zap,
  TrendingUp,
  Users,
  BarChart3,
  Home,
} from "lucide-react";

// SOLID COLORS — NO OPACITY ANYWHERE
const blogData = [
  {
    title: "Top Resume Mistakes to Avoid in 2025",
    content:
      "Craft a winning resume with these practical tips and examples. Stand out from the crowd!",
    path: "/details/TopResumeMistakes",
    icon: FileText,
    bg: "tw-bg-cyan-900",
    text: "tw-text-cyan-300",
  },
  {
    title: "Mastering Technical Interview Questions",
    content:
      "Get ready for the future with real-world technical interview tips and answers.",
    path: "/details/InterviwePrep",
    icon: Terminal,
    bg: "tw-bg-emerald-900",
    text: "tw-text-emerald-300",
  },
  {
    title: "In-Demand Skills for 2025",
    content:
      "Explore trending skills like AI, React, and DevOps that employers want.",
    path: "/details/InDemandSkills",
    icon: Zap,
    bg: "tw-bg-amber-900",
    text: "tw-text-amber-300",
  },
  {
    title: "Job Market Trends",
    content:
      "Stay updated with the latest hiring trends and skills in demand.",
    path: "/details/JobMarketTrends",
    icon: TrendingUp,
    bg: "tw-bg-rose-900",
    text: "tw-text-rose-300",
  },
  {
    title: "How to Build a Strong LinkedIn Profile",
    content:
      "Learn how to build a professional network that opens doors to new opportunities.",
    path: "/details/CareerTipJobApplicationDetails",
    icon: Users,
    bg: "tw-bg-slate-900",
    text: "tw-text-slate-300",
  },
  {
    title: "Career Growth",
    content:
      "Discover strategies for advancing your career and achieving your goals.",
    path: "/details/CareerTipCareerGrowth",
    icon: BarChart3,
    bg: "tw-bg-blue-900",
    text: "tw-text-blue-300",
  },
  {
    title: "How to Stand Out in Online Job Applications",
    content:
      "Enhance productivity and stay connected in a remote or hybrid work environment.",
    path: "/details/HowtoStandOutinOnlineJobApplications",
    icon: Home,
    bg: "tw-bg-purple-900",
    text: "tw-text-purple-300",
  },
];

const CareerTips = () => {
  return (
    <section className="tw-relative tw-py-20 tw-px-4 tw-overflow-hidden tw-font-[Poppins]">

      {/* SOLID Background — NO OPACITY */}
      <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-br tw-from-blue-700 tw-via-purple-700 tw-to-cyan-700"></div>

      {/* Gradient Title */}
      <motion.h3
        className="tw-text-center tw-text-4xl md:tw-text-5xl tw-font-extrabold tw-mb-14 tw-bg-gradient-to-r tw-from-cyan-300 tw-to-blue-400 tw-text-transparent tw-bg-clip-text tw-relative"
        initial={{ opacity: 0, y: -30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        Boost Your Career With Our Insights
      </motion.h3>

      {/* Mobile Swiper */}
      <div className="md:tw-hidden tw-relative">
        <Swiper spaceBetween={20} slidesPerView={1.15}>
          {blogData.map((blog, index) => (
            <SwiperSlide key={index}>
              <motion.div
                whileHover={{ scale: 1.05 }}
                className={`tw-rounded-2xl tw-p-5 tw-shadow-2xl ${blog.bg} tw-border tw-border-white/10 tw-transition`}
              >
                <blog.icon className={`tw-w-10 tw-h-10 tw-mb-4 ${blog.text}`} />

                <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-3">
                  {blog.title}
                </h3>

                <p className="tw-text-sm tw-text-gray-200 tw-mb-4">
                  {blog.content}
                </p>

                <Link
                  to={blog.path}
                  className={`tw-inline-block tw-px-4 tw-py-2 tw-rounded-full tw-border ${blog.text} tw-border-current tw-font-medium tw-text-sm hover:tw-bg-white/10`}
                >
                  Read More →
                </Link>
              </motion.div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>

      {/* Desktop Grid */}
      <div className="tw-hidden md:tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-3 xl:tw-grid-cols-4 tw-gap-10 tw-relative">
        {blogData.map((blog, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.08 }}
            className={`tw-rounded-2xl tw-p-6 tw-shadow-2xl ${blog.bg} tw-border tw-border-white/10 hover:tw-scale-[1.04] tw-transition`}
          >
            <blog.icon className={`tw-w-12 tw-h-12 tw-mb-4 ${blog.text}`} />

            <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-3">
              {blog.title}
            </h3>

            <p className="tw-text-gray-200 tw-text-sm tw-mb-5">
              {blog.content}
            </p>

            <Link
              to={blog.path}
              className={`tw-inline-block tw-px-4 tw-py-2 tw-rounded-full tw-border ${blog.text} tw-border-current tw-font-medium tw-text-sm hover:tw-bg-white/10`}
            >
              Read More →
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default CareerTips;
