
import React from "react";

const AdminDashboard = () => {
  return (
    <div className="container mt-5">
      <h2>Admin Dashboard 🛠️</h2>
      <p>This section is for managing users, settings, and site data.</p>
    </div>
  );
};

export default AdminDashboard;
